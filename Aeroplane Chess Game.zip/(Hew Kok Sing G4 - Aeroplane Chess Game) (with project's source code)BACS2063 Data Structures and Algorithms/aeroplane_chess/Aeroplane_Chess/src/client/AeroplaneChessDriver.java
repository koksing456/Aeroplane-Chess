package client;

import adt.ArrayListWithIterator;
import adt.ArrayQueue;
import adt.ArraySet;
import adt.LinkedList;
import adt.LinkedListInterface;
import adt.ListWithIteratorInterface;
import adt.QueueInterface;
import adt.SetInterface;
import adt.SortedArrayList;
import adt.SortedListInterface;
import entity.Dice;
import entity.Gameplay;
import entity.Leaderboard;
import entity.Player;
import entity.Level;
import entity.Map;
import interfaces.GameplayInterface;
import java.util.Iterator;
import java.util.Scanner;
import entity.Quiz;
import static java.lang.Character.compare;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;

public class AeroplaneChessDriver {

    public static void main(String[] args) {
       
        LinkedListInterface<Player> transferPlayerList = new LinkedList<Player>(); 
        Level transferLevel = new Level();
        Map transferMap = new Map();
        final int MINIMUM_PLAYER = 2;
        
        AeroplaneChessDriver aeroplaneChess = new AeroplaneChessDriver();
        
        mainMenu();
        do
        {
            transferPlayerList = playerMenu();
            if(!transferPlayerList.isEmpty() && transferPlayerList.size() >= 2)
            {
                transferLevel = levelMenu();
                transferMap = map(transferLevel);
                aeroplaneChess.gameplay(transferPlayerList, transferMap, transferLevel); 
            }
            else
                System.out.println("The mimimum number of players is "+ MINIMUM_PLAYER);
        }while(transferPlayerList.isEmpty() || transferPlayerList.size() < 2);
        
    }
//Kok sing--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    private static LinkedListInterface<Player> playerMenu()
    {
        LinkedListInterface<Player> playerList = new LinkedList<Player>(); //player list
        Scanner scan = new Scanner(System.in);
        String choice;
        
        do
        {
                System.out.println("\nPlayer Menu\n--------------\n1. Add Player\n2. View Player\n3. Update Player\n4. Delete Player\n5. Proceed to level selection");
                System.out.print("Select a number to continue: ");
                choice = scan.nextLine(); 

                if(!choice.equals("5"))
                {
                    if(choice.equals("1")) //Add player
                    {
                        do
                        {
                            
                                System.out.print("\nAdd player\n-----------\n1. Add to the end\n2. Add to a specific location\n3. Exit\n\n");
                                System.out.print("Select a number to continue: ");
                                choice = scan.nextLine();

                                if(choice.equals("1")|| choice.equals("2"))
                                {
                                    System.out.print("Enter your name: ");
                                    String name = scan.nextLine();   

                                    String model = "";
                                    do
                                    {
                                        modelMenu();

                                        System.out.print("Select a model by enter number from 1-5: "); 
                                        model = scan.nextLine();
                                        if(model.compareTo("1")<0 || model.compareTo("5") >0)
                                                System.out.println("Invalid model number, please enter again.");
                                    }while(model.compareTo("1")<0 || model.compareTo("5") >0);

                                    Player player = new Player(name,model);

                                    if(choice.equals("1"))
                                        playerList.add(player); 
                                    else if (choice.equals("2"))
                                    {
                                        try
                                        {
                                            System.out.print("Enter an index to add: ");
                                            int index = scan.nextInt();

                                            scan.nextLine();

                                            if((index <= playerList.size() && index > 0) || index == playerList.size()+1)
                                                playerList.add(player, index);
                                            else
                                                System.out.println("Index "+index+" is not valid");
                                        }catch(InputMismatchException ex)
                                        {
                                            System.out.println("Invalid input");
                                        }
                                        
                                        scan.nextLine();
                                    }

                                }else if (choice.equals("3"))
                                    break;
                                else 
                                    System.out.println("Invalid input, please try again.");
                            
                            
                            
 
                        }while(!choice.equals("3"));

                    }
                    else if(choice.equals("2")) //view player 
                    {
                        if(!playerList.isEmpty())
                        {
                            do
                            {
                                
                                    System.out.print("View player\n-----------\n1. Display all Players\n2. Display specific Player\n3. Exit\n\n");
                                    System.out.print("Select a number to continue: ");
                                    choice = scan.nextLine();

                                    if(!choice.equals("3"))
                                    {
                                            if(choice.equals("1"))
                                            {
                                                for(int i=1;i<=playerList.size();i++)
                                                    System.out.println(i+". "+playerList.getElement(i)); 
                                            }
                                            else if (choice.equals("2"))
                                            {
                                                System.out.print("Enter an index to view: ");
                                                String index = scan.nextLine();

                                                if(playerList.getElement(Integer.parseInt(index)) != null)
                                                    System.out.println(playerList.getElement(Integer.parseInt(index)));
                                                else
                                                    System.out.println("The player at index "+index+" does not exist");
                                            }
                                            else
                                                System.out.println("Invalid input, please try again.");
                                    }
                                
                                
                                
                                
                            }while(!choice.equals("3"));
                        }
                        else
                            System.out.println("There is no player to display now.");

                    }
                    else if(choice.equals("3")) //update player
                    { 
                        if(!playerList.isEmpty())
                        {
                            do
                            {
                                
                                    System.out.print("Update player\n-----------\n1. Update Player\n2. Exit\n\n");
                                    System.out.print("Select a number to continue: ");
                                    choice = scan.nextLine();

                                    if(!choice.equals("2"))
                                    {
                                        if(choice.equals("1"))
                                        {
                                            boolean isNull = true;
                                            System.out.print("Enter player name or player index to update: ");
                                            String nameOrIndex = scan.nextLine();

                                            if(Character.isDigit(nameOrIndex.charAt(0)))
                                            {
                                                if(playerList.getElement(Integer.parseInt(nameOrIndex)) != null)
                                                {
                                                    System.out.println(playerList.getElement(Integer.parseInt(nameOrIndex)));
                                                    isNull = false;
                                                }     
                                            }

                                            else 
                                            {
                                                for (int i = 1; i <= playerList.size(); i++)
                                                {
                                                    if(playerList.getElement(i).getName().equals(nameOrIndex))
                                                    {
                                                           System.out.println(playerList.getElement(i));
                                                           isNull = false;    
                                                    }

                                                }
                                            }

                                            if(isNull == false)
                                            {
                                                System.out.print("Confirm to update this player? (y = yes): ");
                                                char yesNo = Character.toLowerCase(scan.nextLine().charAt(0));

                                                if(yesNo == 'y')
                                                {
                                                    System.out.println("Enter new player details\n--------------------------");
                                                    System.out.print("Enter your name: ");
                                                    String name = scan.nextLine();



                                                    String model = "";
                                                    do
                                                    {
                                                        modelMenu();

                                                        System.out.print("Select a model by enter number from 1-5: "); 
                                                        model = scan.nextLine();
                                                        if(model.compareTo("1")<0 || model.compareTo("5") >0)
                                                            System.out.println("Invalid model number, please enter again.");
                                                    }while(model.compareTo("1")<0 || model.compareTo("5") >0);

                                                    Player player = new Player(name,model);

                                                    if(Character.isDigit(nameOrIndex.charAt(0)))
                                                    {
                                                        playerList.update(player, Integer.parseInt(nameOrIndex));
                                                        System.out.println("Update successfully!");
                                                    }      
                                                    else 
                                                    {
                                                        for (int i = 1; i <= playerList.size(); i++)
                                                        {
                                                            if(playerList.getElement(i).getName().equals(nameOrIndex))
                                                            {
                                                                playerList.update(player, playerList.getElement(i));
                                                                System.out.println("Update successfully!");
                                                            }      
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                                System.out.println("The player you entered does not exist");

                                        }else 
                                            System.out.println("Invalid input");     
                                    }
                              

                            }while(!choice.equals("2"));
                        }
                        else
                            System.out.println("There is no player to update now.");



                    }
                    else if(choice.equals("4")) //delete player
                    {
                        if(!playerList.isEmpty())
                        {
                           do
                            {
                                
                                   System.out.print("Delete player\n-----------\n1. Delete Player\n2. Exit\n\n");
                                    System.out.print("Select a number to continue: ");
                                    choice = scan.nextLine();


                                    if(!choice.equals("2"))
                                    {
                                        if(choice.equals("1"))
                                        {
                                            boolean isNull = true;
                                            System.out.print("Enter player name or player index to delete: ");
                                            String nameOrIndex = scan.nextLine();

                                            if(Character.isDigit(nameOrIndex.charAt(0)))
                                            {
                                                if(playerList.getElement(Integer.parseInt(nameOrIndex)) != null)
                                                {
                                                    System.out.println(playerList.getElement(Integer.parseInt(nameOrIndex)));
                                                    isNull = false;
                                                }     
                                            }
                                            else 
                                            {
                                                for (int i = 1; i <= playerList.size(); i++)
                                                {
                                                    if(playerList.getElement(i).getName().equals(nameOrIndex))
                                                    {
                                                           System.out.println(playerList.getElement(i));
                                                           isNull = false;    
                                                    }

                                                }
                                            }

                                            if(isNull == false)
                                            {
                                                System.out.print("Confirm to delete this player? (y = yes): ");
                                                char yesNo = Character.toLowerCase(scan.nextLine().charAt(0));

                                                if(yesNo == 'y')
                                                {
                                                    if(Character.isDigit(nameOrIndex.charAt(0)))
                                                    {
                                                        playerList.remove(Integer.parseInt(nameOrIndex));
                                                        System.out.println("Delete successfully!");
                                                    }

                                                    else 
                                                    {
                                                        for (int i = 1; i <= playerList.size(); i++)
                                                        {
                                                            if(playerList.getElement(i).getName().equals(nameOrIndex))
                                                            {
                                                                playerList.remove(playerList.getElement(i));
                                                                System.out.println("Delete successfully!");
                                                            }

                                                        }
                                                    }
                                                }
                                            }
                                            else
                                                System.out.println("The player you entered does not exist");

                                        }else 
                                            System.out.println("Invalid input");     
                                    } 
                                
                                
                                

                            }while(!choice.equals("2")); 
                        }
                        else
                            System.out.println("There is no player to delete now.");

                    }
                    else
                        System.out.println("Invalid input");
                }   
            
  
        }while(!choice.equals("5"));
        
        
            return playerList;
    }
    
    private static void mainMenu()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("       __|__                    __|__                       __|__\n" +
                          "--o--o--(_)--o--o--      --@--@--(_)--@--@--         --------(_)--------\n"
                + "  O  O       O  O          O  O       O  O             O  O       O  O");
        
        System.out.println("   ___                    __                _______             \n" +
"  / _ |___ _______  ___  / /__ ____  ___   / ___/ /  ___ ___ ___\n" +
" / __ / -_) __/ _ \\/ _ \\/ / _ `/ _ \\/ -_) / /__/ _ \\/ -_|_-<(_-<\n" +
"/_/ |_\\__/_/  \\___/ .__/_/\\_,_/_//_/\\__/  \\___/_//_/\\__/___/___/\n" +
"                 /_/                                            ");
        
        System.out.print("Welcome to the AEROPLANE CHESS game\nPress Enter to continue...");
        scan.nextLine();
    }
    
    private static void modelMenu()
    {
        System.out.println("Model menu\n------------------------\n");
        
        System.out.println("1. Biplane");
        System.out.println("            __/\\__\n" +
                           "           `==/\\==`\n" +
                           " ____________/__\\____________\n" +
                           "/____________________________\\\n" +
                           "  __||__||__/.--.\\__||__||__\n" +
                           " /__|___|___( >< )___|___|__\\\n" +
                           "           _/`--`\\_\n" +
                           "          (/------\\)\n");
        
        System.out.println("2. Stealth bomber ");
        System.out.println(" .-.    _,  .-.  ,_    .-.\n" +
                            "'-._'--'  \\_| |_/  '--'_.-'\n" +
                            "    '-._  \\ | | /  _.-'\n" +
                            "        `-.^| |^.-'\n" +
                            "           `\\=/`\n");
        
        System.out.println("3. Grumman X-29");
        System.out.println("          __\n" +
                            "          \\ \\\n" +
                            "        _  \\ \\\n" +
                            "   ____/ \\_/  \\_\n" +
                            ".-'  ,---,    __|_\n" +
                            "'-.__`---`_    _|\n" +
                            "       \\_/ \\  /\n" +
                            "           / /\n" +
                            "          /_/   \n");
        
        System.out.println("4. General Dynamics F-16 Fighting Falcon");
        System.out.println("  ___\n" +
                            " |   \\\n" +
                            " |    \\                   ___\n" +
                            " |_____\\______________.-'`   `'-.,___\n" +
                            "/| _____     _________            ___>---\n" +
                            "\\|___________________________,.-'`\n" +
                            "          `'-.,__________)\n");
        
        System.out.println("5. McDonnell XF-85 Goblin");
        System.out.println("                    .--.-~-.\n" +
                            "                   /   \\6524\\\n" +
                            "            ____   \\   /====/\n" +
                            "          .`   /`~-.\\ /    /\n" +
                            "    _...-'----'____ ~/    /\n" +
                            " .-~ ==        ````--    /_\n" +
                            " ||== ......              ||\n" +
                            " ||    _____________      ||\n" +
                            " `~-._`~-._         `~._\\  \\\n" +
                            "      `~~--`~-._=======`.\\__\\\n" +
                            "                `~-._____'.\n" +
                            "                    '======`\n");
    }
    private static LinkedListInterface<Quiz> addQuiz()
    {
        LinkedListInterface<Quiz> quizList = new LinkedList<>();
        quizList.add(new Quiz("Which is heavier, the Earth or the Sun?\n","A. Earth\nB. Sun",'B'));
        quizList.add(new Quiz("Which of these is a virus?\n","A. Staphylococcus\nB. Leukemia\nC. Scoliosis\nD. Chicken pox",'D'));
        quizList.add(new Quiz("Which of these has the longest wave length?\n","A. Radio waves\n" +
                                                                            "B. Visible light\n" +
                                                                            "C. X-rays",'A'));
        quizList.add(new Quiz("What is the pH of pure water?\n","A. 0\n" +
                                                            "B. 1\n" +
                                                            "C. 7\n" +
                                                            "D. 273.15",'C'));
        quizList.add(new Quiz("What is the function of mitochondria in the cell?\n","A. To generate energy \n" +
                                                                                    "B. To process waste\n" +
                                                                                    "C. To kill viruses or other antigens\n" +
                                                                                    "D. To repair damage",'A'));
        quizList.add(new Quiz("How old is the Earth approximately?\n","A. 50,000 years\n" +
                                                                    "B. 300 million years\n" +
                                                                    "C. 4.5 billion years \n" +
                                                                    "D. no one knows",'C'));
        quizList.add(new Quiz("What is less dense, hot air or cold air?\n","A. Hot air \n" +
                                                                        "B. Cold air",'B'));
        quizList.add(new Quiz("How many pairs of chromosomes are in the genome of a typical person?\n","A. 1\n" +
                                                                                                    "B. 23 \n" +
                                                                                                    "C. 88\n" +
                                                                                                    "D. 7921",'B'));
        quizList.add(new Quiz("What element do organic compounds contain?\n","A. Carbon \n" +
                                                                            "B. Oxygen\n" +
                                                                            "C. Hydrogen\n" +
                                                                            "D. Nitrogen",'A'));
        quizList.add(new Quiz("Which of these units would you use to measure the total amount of energy it takes to lift a weight a certain distance?\n","A. Watt\n" +
"B. Joule \n" +
"C. Kilogram",'B'));
        quizList.add(new Quiz("How many ring did Kobe Bryant won?\n","A. 4 \n" +
                                                                     "B. 7 \n" +
                                                                     "C. 5 \n" +
                                                                     "D. 9 \n", 'C'));
        quizList.add(new Quiz("Who is coolest?\n", "A. Kok sing\n" +
                                                   "B. Kelvin\n" +
                                                   "C. Kit\n" +
                                                   "D. Songyi\n", 'B'));
        
        return quizList;
    }
    
    private static boolean quiz(LinkedListInterface<Quiz> quizList)
    {
        Scanner scan = new Scanner(System.in);
        
        //validate empty string
        Quiz quiz = quizList.random();
        char playerAnswer = ' ';
        do
        {
            System.out.println(quiz);
            System.out.print("Select an answer: ");
            playerAnswer = Character.toUpperCase(scan.next().charAt(0));
            
            if(compare(playerAnswer, 'A') != 0 && compare(playerAnswer, 'B') != 0 && compare(playerAnswer, 'C') != 0 && compare(playerAnswer, 'D') != 0)
                System.out.println("The answer is invalid"); 
        }while(compare(playerAnswer, 'A') != 0 && compare(playerAnswer, 'B') != 0 && compare(playerAnswer, 'C') != 0 && compare(playerAnswer, 'D') != 0);
        
        quiz.setPlayerAnswer(playerAnswer);
        System.out.println();
        
        if(quiz.getPlayerAnswer() == (quiz.getAnswer()))
        {
            System.out.println("Congratulation, your answer is correct. Please roll dice for your reward ^.^");
            return true;
        }
        else
        {
            System.out.println("Sorry, your answer is wrong. Please roll dice for your punishment ^_^");
            return false;
        }       
    }
    
    
//Kok sing--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
//Christopher--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    private static Level levelMenu(){
        //...
        SetInterface<Level> levelList = new ArraySet<Level>();
        Scanner input = new Scanner(System.in);
        int levelChoice = 0;
        int choiceDifficulty = 1;//should put at top (default)?
        String difficulty;
        int winCondition;
        boolean choiceValid = true;
        
        // should put at the top?
        Level level = new Level();
        Level levelEasy = new Level("Easy", 300);
        Level levelNormal = new Level("Normal", 400);
        Level levelHard = new Level("Hard", 500);
        levelList.add(levelEasy);
        levelList.add(levelNormal);
        levelList.add(levelHard);

        do {
            do {
                //clrscreen
            System.out.printf("\nLevel Menu\n\n"
                            + "      =========================\n"
                            + levelList.getElement(choiceDifficulty)
                            + "      =========================\n"
                            + "\n1. Select Difficulty\n"
                            + "2. Start the game!\n\n"//);
                            + "Enter your choice: ");
            
                    try {
//                        System.out.print("Please enter your choice : ");
                        levelChoice = input.nextInt();
                        if(levelChoice < 1 || levelChoice > 2){
                            System.err.printf("\nInvaild Choice. Press enter to re-enter again.\n");
                        input.nextLine();
                        input.nextLine();
                        }
                        choiceValid = false;
                    } catch (InputMismatchException inputMismatchException) {
                        System.err.println("\nInput number only. Please try again.");
                        input.nextLine();
                        input.nextLine();
                    }
                    
                } while (choiceValid);
            
            if (levelChoice >= 1 && levelChoice <= 2){
                switch (levelChoice) {
                    case 1:  
                        do{
                            //clrscreen
                            int beforeValidChoiceDifficulty = choiceDifficulty;
                            try {
                            //clrscreen
                            System.out.printf("\nSelect difficulty\n\n");
                            for (int i = 0; i < levelList.size(); i++) {
                                System.out.printf("%3d. %s\n", i+1, levelList.getElement(i+1));
                            }
                            System.out.printf("%3d. Back\n\n", levelList.size() + 1);
                            System.out.printf("Choose difficulty: ");
                            
                                beforeValidChoiceDifficulty = input.nextInt();
                                if(beforeValidChoiceDifficulty < 1 || beforeValidChoiceDifficulty > levelList.size() + 1){
                                    System.err.printf("\nInvaild Choice. Press enter to re-enter again.\n");
                                    input.nextLine();
                                    input.nextLine();
                                    
                                    choiceValid = true;
                                }
                                choiceValid = false;   
                            }
                            catch (InputMismatchException inputMismatchException){
                                System.err.println("\nInput number only. Please try again.");
                                input.nextLine();
                                input.nextLine();
                            }
                            
//                            System.out.printf("1. %1d 2. %1d\n", beforeValidChoiceDifficulty, choiceDifficulty);
                            
                            if (beforeValidChoiceDifficulty > 0 && beforeValidChoiceDifficulty <= levelList.size()) {
                                int x = 0;
                                x = beforeValidChoiceDifficulty;
                                choiceDifficulty = x;

                                difficulty = levelList.getElement(choiceDifficulty).getDifficulty();            
                                winCondition = levelList.getElement(choiceDifficulty).getwinCondition();
                                
                                level.setDifficultyNo(choiceDifficulty);
                                level.setDifficulty(difficulty);
                                level.setWinCondition(winCondition);
                            }
//                            System.out.printf("3. %1d 4. %1d\n", beforeValidChoiceDifficulty, choiceDifficulty);

                        }while (choiceValid);//(choiceDifficulty > levelList.size() + 1);
                    break;
                    
                    case 2:
                        difficulty = levelList.getElement(choiceDifficulty).getDifficulty();            
                        winCondition = levelList.getElement(choiceDifficulty).getwinCondition();
                                
                        level.setDifficultyNo(choiceDifficulty);
                        level.setDifficulty(difficulty);
                        level.setWinCondition(winCondition);
                        
                default: // clear screen then show difficulty menu again
                    break;
                }
            }

// clear screen then show difficulty menu again
// prompt error message after choosing wrong option first then clear screen
        } while (levelChoice != 2);

        return level;
    }
//Christopher--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
//Kit--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   
    public static Map map(Level levelDifficulty){
        SortedListInterface<Map> mapList = new SortedArrayList<>();
        Map m1 = new Map("Galaxy X", 50 );
        Map m2= new Map("Space Y", 30 );
        Map m3 = new Map("The Old Town", 40 );
        mapList.add(m1);
        mapList.add(m2);
        mapList.add(m3);
        
        int level = levelDifficulty.getDifficultyNo();
        
        if(level == 1){
            Map temp = mapList.getObject(0);
            System.out.print("\n-----------------------------------------------------------------------------------------------------------------------------------------\n");
            System.out.printf("%20s %10s %15s %20s","-------------------------------------------------","Welcome to ",temp.getName(),"-------------------------------------------------\n");
            System.out.print("-------------------------------------------------------------------------------------------------------------------------------------------\n");
            
            setMap(temp);
            displayMap(temp);
            return temp;
        }
        else if(level ==2){
            Map temp = mapList.getObject(1);
            System.out.print("\n---------------------------------------------------------------\n");
            System.out.print("-----------------------Welcome to "+temp.getName()+"--------------------------\n");
            System.out.print("---------------------------------------------------------------\n");
            
            setMap(temp);
            displayMap(temp);
            return temp;
        }
        else
        {
            Map temp = mapList.getObject(2);
            System.out.print("\n---------------------------------------------------------------\n");
            System.out.print("-----------------------Welcome to "+temp.getName()+"---------------------------\n");
            System.out.print("---------------------------------------------------------------\n");
            
            setMap(temp);
            displayMap(temp);
            return temp;
        }
    }
    
    public static void displayMap(Map m){
        String board[]=m.getBoard();
        
        
        for(int i =0; i< m.getSize();i++){
            if (i % 10 ==0){
                System.out.print("\n");
            }
            System.out.printf("%1s %2s %1s %2s %1s ","|",(i+1),".", board[i],"|");
        }
    }
    
    public static void displaySummaryMap(int size,ListWithIteratorInterface<Gameplay> gameplay){
        ListWithIteratorInterface<Gameplay> gameplayList = gameplay;
        int length=size/10, count =0,a=0,j=0,multiple=0,multipleOfTen=0;
        
        System.out.print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        System.out.print("------------------------------------------------------------------------------------------------------------------Players' current position---------------------------------------------------------------------------------------------------------------\n");
        System.out.print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        for(int i =0; i< length;i++){
            multiple = i+1;
            multipleOfTen = 10*multiple;
            
            while(j <multipleOfTen){
                System.out.printf("%-1s %15d %6s ","|", j,"|");
                j++;
            }
            for(int k=1;k<=gameplayList.size();k++){
                while(a < multipleOfTen ){
                    if(gameplayList.getObj(k).getPlayerPosition()== a){
                        System.out.print("\n");
                        count=a%10 ;
                        while(count>0){
                            System.out.printf("%-1s %15s %6s ","","","");
                            count--;
                        }
                        System.out.printf("%-1s %15s %6s ","|","==>  "+gameplayList.getObj(k).getPlayer().getName(),"|");
                    }
                    a++;
                }
                a-=10;
                
            }
            a+=10;
            System.out.print("\n");
        }
        System.out.print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        System.out.print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n");
    }
    
    public static Map setMap(Map m){
        //------------------------------------------
         
        String board[] = new String[m.getSize()];

        for(int i=0; i< m.getSize();i++){
            if (isFibonanci(i) && i>1)
                board[i] ="Q";
            else if (isPrimeNumber(i)&& i>1)
                board[i] ="T";
            else if (isMultipleOfFive(i)&& i>1)
                board[i] ="B";
            else
                board[i] ="N";
        }
        
        m.setBoard(board);
        
        return  m; 
    }

    public static boolean isMultipleOfFive(int index){
        boolean result = false;
        
        if(index % 5 == 0)
        {
            result = true;

        }

        if (result)
            return true;
        
        return false;
    }
    
    public static boolean isPrimeNumber(int index){
        boolean result = false;
        
        for(int i = 2; i <= index/2; ++i)
        {
            // condition for nonprime number
            if(index % i == 0)
            {
                result = true;
                break;
            }
        }
        
        if (!result)
            return true;
        
        return false;
    }
    public static boolean isFibonanci(int index){
        int array[]= new int[11];
        int i = 0,j=0 , n = 10, t1 = 0, t2 = 1;
        
        while (i <= n)
        {
            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
            array[i] = sum;
 
            i++;
        }
        
        while(j<=n){
            if(index== array[j])
                return true;
            j++;
        }
        
        
      return false;   
  }
//Kit--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    
    
//Kelvin--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //main 
  public void gameplay(LinkedListInterface<Player> playerList, Map map, Level level){ 
  
        ListWithIteratorInterface<Gameplay> startGameplayList = new ArrayListWithIterator<>();
        ListWithIteratorInterface<Gameplay> transferGameplayList = new ArrayListWithIterator<>();
        ListWithIteratorInterface<Gameplay> endGameplayList = new ArrayListWithIterator<>();
        
        //Add gameplay to list
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
        Date startTime = new Date();
        String stringStartTime = formatter.format(startTime);
        for(int position = 1; position <= playerList.size(); position++){
            startGameplayList.add(new Gameplay(playerList.getElement(position), stringStartTime));
        }
        
        System.out.print("\n");
        System.out.print("\n");
        System.out.println("**********Welcome**********");
        startGameplayList.subList(1, startGameplayList.size());
        System.out.println("\n");
        System.out.println("**********Thanks For Playing Aeroplane Chess**********");
        
        //Playing     
        int winCondition = level.getwinCondition(); 
        int mapSize = map.getBoard().length; 
        String[] mapArr = map.getBoard(); 
        
        int playerIndex = 1;
        int round = 1;
        int countEndGameIndex = 0;
        
        do{
            Gameplay tempGameplay = (Gameplay) gameplayController(startGameplayList.getObj(playerIndex), mapSize, mapArr, round); // 21/8/2020
            startGameplayList.replace(playerIndex, tempGameplay); 
            
            System.out.print("\n");
            System.out.println("...Player Turn Ended...");
            
            if(tempGameplay.getCoin() >= winCondition){
                
                Date endTime = new Date();
                String stringEndTime = formatter.format(endTime);
                endGameplayList.add(startGameplayList.remove(tempGameplay));
                countEndGameIndex++;
                endGameplayList.getObj(countEndGameIndex).setEndTime(stringEndTime);
                endGameplayList.replace(countEndGameIndex, tempGameplay);
                
                System.out.println("-------------------------------------------");
                System.out.println("Congratulation to " + tempGameplay.getPlayer().getName() + " for finishing the game ");
                System.out.println(endGameplayList.getObj(countEndGameIndex));
                System.out.println("\n");
                System.out.println("--------------------------------------------");
                playerIndex = 1;
                promptEnterKey();
                //System.out.print("\n");
                finalLeaderboard(endGameplayList);         
            }
            else{  
                System.out.println("--------------------------------------------------------------------------------------");   
                System.out.println("\n");
                System.out.println("Player " + tempGameplay.getPlayer().getName() + " round ended, showing current player summary");
                promptEnterKey();
                System.out.println("-------------------------------------------");
                System.out.println(startGameplayList.getObj(playerIndex));
                System.out.println("-------------------------------------------");
                playerIndex++;
            }
            
            if(playerIndex > startGameplayList.size() && startGameplayList.size() != 0){
                
                playerIndex = 1;
                
                System.out.println("\n");
                System.out.println("-------------------------------------------");
                System.out.println("        Summary of round " + round );
                System.out.println("-------------------------------------------");
                System.out.println("-------------------------------------------");
                displayList(startGameplayList);
                System.out.println("-------------------------------------------");
                
                transferGameplayList.addAll(startGameplayList);
                promptEnterKey();
                displaySummaryMap(mapSize,transferGameplayList);
                Leaderboard(transferGameplayList);

                round++;
                System.out.print("\n");
                promptEnterKey();
            }
            
        }while(startGameplayList.size() > 1);
        
        endGameplayList.add(startGameplayList.remove(1));
        Date endTime = new Date();
        String stringEndTime = formatter.format(endTime);
        countEndGameIndex++;
        Gameplay lastGameplay = endGameplayList.getObj(countEndGameIndex);
        lastGameplay.setEndTime(stringEndTime);
        endGameplayList.replace(countEndGameIndex, lastGameplay);
        
        System.out.println("<<All player end game status>>");
        displayList(endGameplayList);
        System.out.print("\n");
        promptEnterKey();
        finalLeaderboard(endGameplayList); 
        System.out.println("----------------------------------------------------------");
        System.out.println("*******************Yay, Game have ended*******************");
        System.out.println("----------------------------------------------------------");
    }
    
    //controller
    public GameplayInterface gameplayController(Gameplay gameplay, int mapSize, String[] map, int round){ // 21/8/2020
         
        Scanner scan = new Scanner(System.in);
        String playerName = gameplay.getPlayer().getName();
        
         LinkedListInterface<Quiz> quizList = addQuiz();
        
        
        GameplayInterface resultInterface = gameplay;
            
        System.out.print("\n");
        System.out.println("Player " + playerName + " turn to roll dice");
        System.out.println("--------------------------------------------------------------------------------------");
        
        char reroll;
        int dice;
      
        dice = rollDice();
        System.out.println("> You rolled a " + dice);
        System.out.println("Do you want to reroll? Use 50 coin to reroll");
        System.out.print("Once per round, (y = yes / others = no):");
        reroll = scan.next().charAt(0);
        
       
        if(reroll == 'y' || reroll == 'Y'){
            
            if(resultInterface.getCoin() >= 50){
            subtractCoin(resultInterface, 50);
            dice = rollDice();
            System.out.println("> You rolled a " + dice + " you will move forward " + dice + " position");
            System.out.println("--------------------------------------------------------------------------------------");
            
            }
            else{
                
               System.out.println("--------------------------------------------------------------------------------------");
               System.out.println("You do not have enough coin!!!. We will be using your previous roll");  
               promptEnterKey();
            }
        }
        
        
        int playerPosition = positionAdvance(resultInterface, dice, mapSize);
        
        if(map[playerPosition].equals("Q")){
            
            System.out.print("\n");
            System.out.println("You get a quiz!!!");
            System.out.print("\n");
           
            if(quiz(quizList)){
                int temp = rollDice();
                int total = temp*2;
                
               System.out.println("--------------------------------------------------------------------------------------");
                if(temp % 2 == 0){
                    System.out.println("You get a bonus of " + total + " coin yay!!!");
                    addCoin(resultInterface, total);
                }
                else{
                    System.out.println("You get to advance " + temp + " step yay!!!");
                    positionAdvance(resultInterface, temp, mapSize);
                }
            }
            else{
                int temp = rollDice();
                int total = temp*2;
                
                System.out.println("--------------------------------------------------------------------------------------");
                if(temp % 2 == 0){
                    System.out.println("No your coin deducted a total of " + total + " !!!");
                    subtractCoin(resultInterface, total);
                }
                else{
                    System.out.println("No you need to go back " + temp + " step!!!");
                    positionDecrease(resultInterface, temp, mapSize, round);
                }
            }
        }
        else if(map[playerPosition].equals("T")){
            
            System.out.print("\n");
            System.out.println("Opps, It's a trap!!!");
            System.out.print("\n");
           
            int temp = rollDice();
            int total = temp*2;

            System.out.println("--------------------------------------------------------------------------------------");
            if(temp % 2 == 0){
                System.out.println("No your coin deducted a total of " + total + " !!!");
                subtractCoin(resultInterface, total);
            }
            else{
                System.out.println("No you need to go back " + temp + " step!!!");
                positionDecrease(resultInterface, temp, mapSize, round); // 21/8/2020
            }
        }
        else if(map[playerPosition].equals("B")){
            System.out.print("\n");
            System.out.println("Yeah, It's a bonus!!!");
            System.out.print("\n");
           
            int temp = rollDice();
            int total = temp*2;
            System.out.println("--------------------------------------------------------------------------------------");
            if(temp % 2 == 0){
                System.out.println("You get a bonus of " + total + " coin yay!!!");
                addCoin(resultInterface, total);
            }
            else{
                System.out.println("You get to advance " + temp + " step yay!!!");
                positionAdvance(resultInterface, temp, mapSize);
            }
        }
                
        return resultInterface;
    }
 
    //gameplay interface
    public int addCoin(GameplayInterface gameplayInterface, int coin){
        
        return gameplayInterface.addCoin(coin);
    }
    
    public int subtractCoin(GameplayInterface gameplayInterface, int coin){
        
        return gameplayInterface.subtractCoin(coin);
    }

    public int positionAdvance(GameplayInterface gameplayInterface, int position, int mapSize){ 
               
        int tempPosition = gameplayInterface.advancePlayerPosition(position);
        
        if(tempPosition >= mapSize){ 
            if(gameplayInterface.isRevert()){ // 21/8/2020
                tempPosition = resetPlayerPosition(gameplayInterface, tempPosition - mapSize);
                gameplayInterface.setRevert(false);
            } //
            else{
                System.out.println("\n");
                System.out.println("!!!You completed a round, 100 coin is rewarded!!!");
                addCoin(gameplayInterface, 100);
                tempPosition = resetPlayerPosition(gameplayInterface, tempPosition - mapSize);
            }
        }
        
        return tempPosition;
    }
    
    public int positionDecrease(GameplayInterface gameplayInterface, int position, int mapSize, int round){
        
        int tempPosition = gameplayInterface.decreasePlayerPosition(position);
        
        if(tempPosition < 0){
            if(round == 1) // 21/8/2020
                tempPosition = resetPlayerPosition(gameplayInterface, 0); 
            else
                tempPosition = resetPlayerPosition(gameplayInterface, position + mapSize);
                gameplayInterface.setRevert(true);  //
        }
        
        return tempPosition;
    }
    
    public int resetPlayerPosition(GameplayInterface gameplayInterface, int position){
        
        return gameplayInterface.resetPlayerPosition(position);
    }
    
    public int rollDice(){
        
        GameplayInterface rollDiceInterface = new Gameplay();
        
        Dice dice = rollDiceInterface.rollDice();
        
        Scanner scan = new Scanner(System.in);
        char action;
        
        do{
         System.out.print("Press 1 to roll dice: ");
         action = scan.next().charAt(0);
        }while(compare(action, '1')!= 0);
        
        return dice.getValue();
    }
    //end of gameplay interface
    public <T> void displayList(ListWithIteratorInterface<T> list){ 
        Iterator<T> iterate = list.getIterator();
        
        while(iterate.hasNext()){
           System.out.println(iterate.next());
        }
    }
    
    public void promptEnterKey(){
        System.out.print("Press enter to continue...");
        Scanner scan = new Scanner(System.in);
        scan.nextLine();
    }
//Kelvin--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   
//Songyi--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
public void Leaderboard(ListWithIteratorInterface<Gameplay> rankingList) {
        
        ListWithIteratorInterface<Gameplay> gameplayList = rankingList;
        QueueInterface<Leaderboard> player = new ArrayQueue<>(gameplayList.size());
        QueueInterface<Leaderboard> ranking = new ArrayQueue<>(gameplayList.size());
        for(int i=1;i<=gameplayList.size();i++)
        {
            //Leaderboard player = new Leaderboard(gameplayList.getObj(1);
            player.add(new Leaderboard(gameplayList.getObj(i)));
        }
        
        int[] coin =  new int[gameplayList.size()];
        
        for(int i = 0;i<=gameplayList.size()-1;i++){
            coin[i] = player.peekAt(i).getGameplay().getCoin();
        }
        
        coin = sort(coin);
        
        for(int i = gameplayList.size()-1;i>=0;i--){
            for(int j = 0;j<=i;j++){
                if(player.peekAt(j)!=null){
                    if(player.peekAt(i).getGameplay().getCoin() == player.peekAt(j).getGameplay().getCoin() && player.peekAt(i).getGameplay().getPlayer().getPlayerID() != player.peekAt(j).getGameplay().getPlayer().getPlayerID()){
                        ranking.add(player.peekAt(i));
                        player.removeAt(i);
                        j = i+1;

                    }else if(coin[i] == player.peekAt(j).getGameplay().getCoin()){
                        ranking.add(player.peekAt(j));
                        player.removeAt(j);
                    }
                }
            }
        }
        
        player.clear();
        System.out.println("Round LEADERBOARD");
        System.out.println("---------------------------------------");
        System.out.printf("%4s  %12s  %4s  %8s\n","Rank","Player Name","Coin","Position");
        System.out.println("---------------------------------------");
        for(int pRanking = 0;pRanking<=gameplayList.size()-1;pRanking++){
            if(ranking.peekAt(pRanking)!= null)
                System.out.printf("%4d  %12s  %4d  %8d\n",pRanking+1 , ranking.peekAt(pRanking).getGameplay().getPlayer().getName(), 
                        ranking.peekAt(pRanking).getGameplay().getCoin(),ranking.peekAt(pRanking).getGameplay().getPlayerPosition());
            
        }
        ranking.clear();
        gameplayList.clear();
    }

public void finalLeaderboard(ListWithIteratorInterface<Gameplay> transferGameplayList){
    
    ListWithIteratorInterface<Gameplay> winnerList = transferGameplayList;
    QueueInterface<Leaderboard> winner = new ArrayQueue<>(winnerList.size());
    
    for(int adding=1;adding<=winnerList.size();adding++){
        winner.add(new Leaderboard(adding,winnerList.getObj(adding)));
        //System.out.println("Current winner ranking:");

    }
    
    System.out.println("\nCurrent winner ranking:");
    System.out.println("---------------------------------------");
    for(int j = 0;j<=winnerList.size()-1;j++){
       
        if(winner.peekAt(j).getPosition() == winnerList.size() && winnerList.size()>1)
            System.out.println("LOSE "+winner.peekAt(j).getGameplay().getPlayer().getName()+" End Time:"+
                    winner.peekAt(j).getGameplay().getEndTime());
        else if(winner.peekAt(j) != null)
            System.out.println(winner.peekAt(j).getPosition()+" "+winner.peekAt(j).getGameplay().getPlayer().getName()+" End Time:"+
                    winner.peekAt(j).getGameplay().getEndTime());
    }
    
    winner.clear();
}

public static int[] sort(int[] value){
        
        int[] orderedNums =  new int[value.length];
        for(int indexL=0;indexL<value.length;indexL++)
        {
            int greater=0;
            for(int indexR=0;indexR<value.length;indexR++)
            {
                if(value[indexL]>value[indexR])
                {
                    greater++;
                }
            }
            while (orderedNums[greater] == value[indexL]) {
                greater++;
            }
            orderedNums[greater] = value[indexL];
        }
        
        return orderedNums;
    }
//Songyi--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    
}
