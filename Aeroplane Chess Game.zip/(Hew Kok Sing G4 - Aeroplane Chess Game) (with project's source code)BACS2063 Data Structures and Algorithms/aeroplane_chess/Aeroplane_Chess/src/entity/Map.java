package entity;

public class Map implements Comparable<Map>{
    private String name;
    private String board[];
    private int size;
    private int mapID =0;
    private static int nextMapID = 100;
    
    public Map(){
        
    }
    
    public Map(String name, int size){
            this.size = size;
            this.name = name;
            this.mapID = nextMapID++;
            
            String[] temp = new String[size];
            board = temp;
    }

    public String getName(){
        return name;
    }
    
    public int getMapID(){
        return mapID;
    }

    public int getSize(){
        return size;
    }
    
    public void setName(String name){
        this.name =name;
    }
    
    public void setMapID(int mapID){
        this.mapID = mapID;
    }
    
    public void setSize(int size){
        this.size = size;
    }

    public String[] getBoard() {
        return board;
    }

    public void setBoard(String[] board) {
        this.board = board;
    }
    
    @Override
    public String toString() {
       return "\nMap ID: " +mapID+
               "\nName: "+name+
              "\nSize: "+size;
    }

    @Override
    public int compareTo(Map m) {
        int compareSize=((Map)m).getSize();
        
        return this.size- compareSize;
    }
    
     
}