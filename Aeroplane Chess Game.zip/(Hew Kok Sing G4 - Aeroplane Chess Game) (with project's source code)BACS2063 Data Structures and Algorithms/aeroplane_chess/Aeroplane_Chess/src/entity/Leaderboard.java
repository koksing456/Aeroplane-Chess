package entity;

import java.util.Objects;

public class Leaderboard {
    private Gameplay gameplay;
    private int position;
    
    public Leaderboard(){
    }
    
    public Leaderboard(Gameplay gameplay){
        this.gameplay= gameplay;
    }
    
    public Leaderboard(int position ,Gameplay gameplay){
        this.position = position;
        this.gameplay= gameplay;
    }
    
    public Gameplay getGameplay() {
        return gameplay;
    }
    
    public void setGameplay(Gameplay gameplay) {
        this.gameplay = gameplay;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getPosition() {
        return position;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.gameplay);
        hash = 53 * hash + this.position;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Leaderboard other = (Leaderboard) obj;
        return true;
    }

    @Override
    public String toString() {
        return "gameplay=" + gameplay + ", position=" + position;
    }
    

}
