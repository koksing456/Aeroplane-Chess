package entity;

import java.util.Objects;

public class Dice {
    
    private int value;
    private String diceType = "Normal Dice";
    private static int diceAmount = 2;
    
    public Dice(){
        
    }
    
    public Dice(int value){
        this.value = value;
    }
    
    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDiceType() {
        return diceType;
    }

    public void setDiceType(String diceType) {
        this.diceType = diceType;
    }

    public int getDiceAmount() {
        return diceAmount;
    }

    public void setDiceAmount(int diceAmount) {
        this.diceAmount = diceAmount;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + this.value;
        hash = 67 * hash + Objects.hashCode(this.diceType);
        hash = 67 * hash + this.diceAmount;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Dice other = (Dice) obj;
        if (this.value != other.value) {
            return false;
        }
        if (this.diceAmount != other.diceAmount) {
            return false;
        }
        if (!Objects.equals(this.diceType, other.diceType)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Dice{" + "value=" + value + ", diceType=" + diceType + ", diceAmount=" + diceAmount + '}';
    }  
}
