package entity;

import java.util.Objects;

public class Level {
    
    private int difficultyNo;
    private static int nextDifficultyNo = 1;
    private String difficulty; // [1] !char | temp 1,2,3 = easy, normal, hard
    private int winCondition; // [1]
    // temp coin(winCondition) = 100, 200, ...
    
    public Level(){
        
    }
    
    public Level(String difficulty, int winCondition){ 
        difficultyNo = nextDifficultyNo++;
        this.difficulty = difficulty;
        this.winCondition = winCondition;
    }
    
    public void setDifficultyNo(int difficultyNo) {
        this.difficultyNo = difficultyNo;
    }
    
    public int getDifficultyNo() {
        return difficultyNo;
    }
    
    public void setDifficulty(String difficulty){ 
        this.difficulty = difficulty;
    }
    
    public String getDifficulty(){ 
        return difficulty;
    }
    
    public void setWinCondition(int winCondition){ 
        this.winCondition = winCondition;
    }
    
    public int getwinCondition(){ 
        return winCondition;
    }
    
    public int hashCode(){
        int hash = 3;
        hash = 137 * hash + this.difficultyNo;
        hash = 137 * hash + Objects.hashCode(this.difficulty);
        hash = 137 * hash + this.winCondition;
        return hash;
    }
    
    public boolean equals(Object obj){
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Level other = (Level) obj;
        
        if (!Objects.equals(this.difficultyNo, other.difficultyNo)) {
            return false;
        }
        if (!Objects.equals(this.difficulty, other.difficulty)) {
            return false;
        }
        if (!Objects.equals(this.winCondition, other.winCondition)) {
            return false;
        }
        
        return true;
    }
    
    public String toString() {
        return "\tDifficulty   : " + difficulty + "\n\tWin Condition: " + winCondition + " Coins" + "\n";
    }
    
}
