package entity;

import java.util.Objects;

public class Player {
    private static int nextPlayer = 1001;
    private String name;
    private String model;
    private int playerID; //auto generate

    public Player() {
        this.playerID = nextPlayer++;
    }

    public Player(String name, String model) {
        this.name = name;
        this.model = model;
        this.playerID = nextPlayer++;
    }
    

    public String getName() {
        return name;
    }

    public String getModel() {
        return model;
    }
    
     public int getPlayerID() {
        return playerID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.name);
        hash = 89 * hash + Objects.hashCode(this.model);
        hash = 89 * hash + this.playerID;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Player other = (Player) obj;
        if (this.playerID != other.playerID) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.model, other.model)) {
            return false;
        }
        return true;
    }
    
    private String getModelName(String modelNum)
    {
        String modelName="";
        if(modelNum.equals("1"))
                            modelName = "1. Biplane\n"+"            __/\\__\n" +
                           "           `==/\\==`\n" +
                           " ____________/__\\____________\n" +
                           "/____________________________\\\n" +
                           "  __||__||__/.--.\\__||__||__\n" +
                           " /__|___|___( >< )___|___|__\\\n" +
                           "           _/`--`\\_\n" +
                           "          (/------\\)\n";
        else if(modelNum.equals("2"))
                            modelName =  "2. Stealth bomber\n"       +   " .-.    _,  .-.  ,_    .-.\n" +
                            "'-._'--'  \\_| |_/  '--'_.-'\n" +
                            "    '-._  \\ | | /  _.-'\n" +
                            "        `-.^| |^.-'\n" +
                            "           `\\=/`\n";
        else if(modelNum.equals("3"))
            modelName = "3. Grumman X-29\n"+"          __\n" +
                            "          \\ \\\n" +
                            "        _  \\ \\\n" +
                            "   ____/ \\_/  \\_\n" +
                            ".-'  ,---,    __|_\n" +
                            "'-.__`---`_    _|\n" +
                            "       \\_/ \\  /\n" +
                            "           / /\n" +
                            "          /_/   \n";
        else if(modelNum.equals("4"))
            modelName = "4. General Dynamics F-16 Fighting Falcon\n"+"  ___\n" +
                            " |   \\\n" +
                            " |    \\                   ___\n" +
                            " |_____\\______________.-'`   `'-.,___\n" +
                            "/| _____     _________            ___>---\n" +
                            "\\|___________________________,.-'`\n" +
                            "          `'-.,__________)\n";
        else 
            modelName = "5. McDonnell XF-85 Goblin\n"+"                    .--.-~-.\n" +
                            "                   /   \\6524\\\n" +
                            "            ____   \\   /====/\n" +
                            "          .`   /`~-.\\ /    /\n" +
                            "    _...-'----'____ ~/    /\n" +
                            " .-~ ==        ````--    /_\n" +
                            " ||== ......              ||\n" +
                            " ||    _____________      ||\n" +
                            " `~-._`~-._         `~._\\  \\\n" +
                            "      `~~--`~-._=======`.\\__\\\n" +
                            "                `~-._____'.\n" +
                            "                    '======`\n";
        
        return modelName;
    }
    
    @Override
    public String toString() {
       return "\nPlayer ID: " +playerID+
               "\nName: "+name+
              "\nModel: "+getModelName(model);         
    }
    
}
