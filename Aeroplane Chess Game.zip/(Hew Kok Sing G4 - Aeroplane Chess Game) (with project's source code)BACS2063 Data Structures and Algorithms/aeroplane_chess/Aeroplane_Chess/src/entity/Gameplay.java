package entity;

import interfaces.GameplayInterface;
import java.util.Date;
import java.util.Objects;
import java.util.Random;

public class Gameplay implements GameplayInterface{
    
    private Player player; 
    private String startTime;
    private String endTime = "Pending";
    private int coin = 100;  
    private int playerPosition = 0; 
    private Dice dice;
    private boolean revert = false;
    
    public Gameplay(){
        
    }
     
    public Gameplay(Player player, String time){
        this.player = player;
        this.startTime = time;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    
    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }

    public int getPlayerPosition() {
        return playerPosition;
    }

    public void setPlayerPosition(int playerPosition) {
        this.playerPosition = playerPosition;
    }

    public Dice getDice() {
        return dice;
    }

    public void setDice(Dice dice) {
        this.dice = dice;
    }

    public boolean isRevert() {
        return revert;
    }

    public void setRevert(boolean revert) {
        this.revert = revert;
    }

    @Override
    public String toString() {
        return "\nPlayer Status:" + 
                "" + player + 
                "\nStart Time:" + startTime + 
                "\nEnd Time:" + endTime + 
                "\nCoin:" + coin + 
                "\nPlayer Position:" + playerPosition;
    }

    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.player);
        hash = 17 * hash + Objects.hashCode(this.startTime);
        hash = 17 * hash + Objects.hashCode(this.endTime);
        hash = 17 * hash + this.coin;
        hash = 17 * hash + this.playerPosition;
        hash = 17 * hash + Objects.hashCode(this.dice);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Gameplay other = (Gameplay) obj;
        if (this.coin != other.coin) {
            return false;
        }
        if (this.playerPosition != other.playerPosition) {
            return false;
        }
        if (!Objects.equals(this.player, other.player)) {
            return false;
        }
        if (!Objects.equals(this.startTime, other.startTime)) {
            return false;
        }
        if (!Objects.equals(this.endTime, other.endTime)) {
            return false;
        }
        if (!Objects.equals(this.dice, other.dice)) {
            return false;
        }
        return true;
    }


    
   //operation
    public int addCoin(int coin){
        
        //Gameplay gameplay = new Gameplay();
        
        this.coin = this.coin + coin; 
        
        return this.coin;
    }
    
    public int subtractCoin(int coin){
         
        if(this.coin < coin){
            this.coin = 0;
        }
        else{
            this.coin = this.coin - coin;
        }
         
        return this.coin;
    }
    
    public int advancePlayerPosition(int positionIncrease){
        
        return this.playerPosition = this.playerPosition + positionIncrease;
    }
    
    public int decreasePlayerPosition(int positionDecrease){
        
        return this.playerPosition = this.playerPosition - positionDecrease;
    }
    
    public int resetPlayerPosition(int resetPosition){
        
        return this.playerPosition = resetPosition;
    }
    
    public Dice rollDice(){
        
        Random rollDice = new Random();
        
        int rand=0;
        while(true){
            rand = rollDice.nextInt(13);
            if(rand > 1) break;
        }
        
        Dice dice = new Dice(rand);
        
        return this.dice = dice;
    }
}
