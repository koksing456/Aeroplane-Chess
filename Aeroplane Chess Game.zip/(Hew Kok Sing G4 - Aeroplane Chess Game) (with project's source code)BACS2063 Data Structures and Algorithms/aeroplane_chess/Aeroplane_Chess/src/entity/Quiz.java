
package entity;

import java.util.Objects;

public class Quiz {
    private String question;
    private String choice;
    private char answer;
    private char playerAnswer;

    public Quiz(String question, String choice, char answer) {
        this.question = question;
        this.choice = choice;
        this.answer = answer;
    }
    
    
    public Quiz(String question, String choice, char answer, char playerAnswer) {
        this.question = question;
        this.choice = choice;
        this.answer = answer;
        this.playerAnswer = playerAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public String getChoice() {
        return choice;
    }

    public char getAnswer() {
        return answer;
    }
    

    public char getPlayerAnswer() {
        return playerAnswer;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }

    public void setAnswer(char answer) {
        this.answer = answer;
    }

    public void setPlayerAnswer(char playerAnswer) {
        this.playerAnswer = playerAnswer;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + Objects.hashCode(this.question);
        hash = 13 * hash + Objects.hashCode(this.choice);
        hash = 13 * hash + Objects.hashCode(this.answer);
        hash = 13 * hash + Objects.hashCode(this.playerAnswer);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Quiz other = (Quiz) obj;
        if (!Objects.equals(this.question, other.question)) {
            return false;
        }
        if (!Objects.equals(this.choice, other.choice)) {
            return false;
        }
        if (!Objects.equals(this.answer, other.answer)) {
            return false;
        }
        if (!Objects.equals(this.playerAnswer, other.playerAnswer)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return question + choice;
    }
    
    
}
