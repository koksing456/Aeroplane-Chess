package adt;

public interface SortedListInterface<T extends Comparable<T>> {

  public boolean add(T newObject);
    //Description: Add new object and sorted it to the list.
    //Precondition: The list is not full.
    //Postcondition: The newObject sorted and added to the specified index of the list.
    //Return: Return true if the newObj succesfully added.
  
  public boolean remove(T object);
    //Description: Remove the object from the list.
    //Precondition: The object is not null and contains in the list.
    //Postcondition: The object is deleted from the list.
    //Return: Return true if the object is successfully deleted from the list. Otherwise will be false.
  
  public boolean contains(T object);
    //Description: Check if the object exist in the list.
    //Return: Return true if object exist in the list.
  
  public void clear();
    //Description: Delete all object in the list.
    //Precondition: The list should not be empty.
    //Postcondition: All object is deleted from the list and the size of list reset to zero.
  
  public int getLength();
    //Description: get the number of object in the list.
    //Precondition: The list must not be null.
    //Return: Return the number of object in the list.
  
  public boolean isEmpty();
    //Description: Check if the list is empty.
    //Return: Return true if the list is empty.
  
  public boolean isFull();
    //Description: Check if the list is full.
    //Return: Return true iff the list is full.
  
  public T getObject(int position);
    //Description: Get object from the list at the given position.
    //Precondition: The position must be contain the number of object in the list.
    //Postcondition: The object has been obtained from the given position in the list.
    //Return: Return the object from the list at the given position.

  public int checkPosition(T object); 
    //Description: Check the position of the object.
    //Precondition: The object is not null and contains in the list.
    //Postcondition: Get the position of the object.
    //Return: Return the position of the object, otherwise return 0
} 
