package adt;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayListWithIterator<T> implements ListWithIteratorInterface<T>{
    
  private T[] array;
  private int size;
  private static final int DEFAULT_CAPACITY = 5;
  
    public ArrayListWithIterator(){
        this(DEFAULT_CAPACITY);
    }
  
    public ArrayListWithIterator(int initialCapacity) {
        size = 0;

        @SuppressWarnings("unchecked")
        T[] tempList = (T[]) new Object[initialCapacity];
        array = tempList;
    }
        
    public boolean add(T newObj){ //
        if(isFull()){
            return false;
        }
        array[size] = newObj;
        size++;
        return true;
    }

    public boolean add(int position, T newObj){ //
        boolean success = false;
        
        if(isFull())
            return success;
        if(position > 0 && position <= size + 1){
                move(position);
                array[position - 1] = newObj;
                size++; 
                
                success = true;
        }
        return success;
    }
 
    public boolean addAll(ListWithIteratorInterface<T> list){ //
       int tempLength = list.size();
       int tempIndex = 1;
       
        if(tempLength + size  > array.length){
            return false;
        }
        
        for(int index = 0; index < tempLength ; index++){
            array[size] = list.getObj(tempIndex);
            tempIndex++;
            size++;
        }
        return true;
    }
    
    public void subList(int fromPosition, int toPosition){ //
        int fromIndex = fromPosition - 1;
        
        if(fromPosition > 0 && toPosition <= size){
            for(int index = fromIndex; index < toPosition; index++){
                System.out.println(array[index]);
            }
        }
        else{
            System.out.println("Unable to locate element");
        }
    }

    public boolean contains(T obj){  //
        boolean found = false;
        
        for(int index = 0; found == false && index < size; index++){
            if(obj.equals(array[index])){
                found = true;
            }
        }
        return found;
    }

    public T getObj(int position){ //
        T result = null;
        
        if(position > 0 && position <= size){
            result = array[position - 1];
        }
        return result;
    }

    public T remove(T obj){ //
        T result = null;
        
        int tempPosition = checkPosition(obj);
        result = remove(tempPosition);
        return result;
    }
    
    public T remove(int position){ //
        T result = null;
        
        if(position > 0 && position <= size){
            result = array[position - 1];
            
            if(position < size){
                removeGap(position);
            }
            size--;
        }
        return result;
    }

    public boolean removeRange(int fromPosition, int toPosition){ //
        boolean result = true;
        
        if(fromPosition < 1 || toPosition > size){
            return result = false;
        }
        for(int index = fromPosition; index <= toPosition; index++){
            remove(fromPosition); 
        }
        return result;
    }
      
    public boolean replace(int position, T newObj){  //
        boolean success = false;
        
        if(position > 0 && position <= size){
            array[position - 1] = newObj;
            success = true;
        }
        return success;
    }
    
    public boolean replace(T obj, T newObj){ //
        boolean success = false;
        
        
        for(int index = 0; index < size; index++){
            if(obj == array[index]){
                array[index] = newObj;
                return success;
            }
        }
        return success;
    }
 
    public void clear(){ //
        size = 0;
    }
  
    public boolean isFull(){ //
        return isArrayFull();
    }

    public int size(){ //
        return size;
    }
  
    public boolean isEmpty(){ //
        return size == 0;
    }
    
    //Utility
    private void move(int position){ //
        int entryIndex = position - 1;
        int lastIndex = size - 1;
        
        for(int index = lastIndex; index >= entryIndex; index--){
            array[index + 1] = array[index];
        }
    }
    
    private void removeGap(int position){ //
        int removeIndex = position - 1;
        int lastIndex = size - 1;
        
        for (int index = removeIndex; index < lastIndex; index++) {
            array[index] = array[index + 1];
        }
    }
    
    public int checkPosition(T obj){ //
        int position = 0;
        
        for(int index = 0; index < size; index++){
            if(obj == array[index]){
                position = index + 1;
            }
        }
        return position;
    }
    
    private boolean isArrayFull(){ //
        return size == array.length;
    }
    
    public String toString() { //
        String outputStr = "";
        for (int index = 0; index < size; ++index) {
            outputStr += array[index] + "\n";
         }

        return outputStr;
    }
    
    @Override
    public Iterator<T> getIterator() { //
        return new IteratorForArrayList();
    }

    
    private class IteratorForArrayList implements Iterator<T>{
        
        private int nextIndex;
        private boolean isNextCalled;
        
        private IteratorForArrayList() {
        nextIndex = 0;
        isNextCalled = false;
        }
        
        @Override
        public boolean hasNext(){ 
            return nextIndex < size;
        }
        
        @Override
        public T next(){ 
            if(hasNext()){
                isNextCalled = true; //use to remove iterated object
                T nextObj = array[nextIndex];
                nextIndex++;
                
                return nextObj;
            }
            else {
                throw new NoSuchElementException("Illegal call to next();"
                + "iterator is after end of list.");
            }
        }

        public void remove(){ 
            if(isNextCalled){
                ArrayListWithIterator.this.remove(nextIndex);
                nextIndex--;
                isNextCalled = false;
            }
            else{
                throw new IllegalStateException("Illegal call to remove(); "
                + "next() was not called.");
            }
        } 
    }
}
