
package adt;

public class ArraySet<T> implements SetInterface<T> {
    
//    private Node firstNode;
    T[] setArray;
    int numberOfElements;
    private static final int DEFAULT_INITIAL_CAPACITY = 10;
    
//    private class Node{
//        private T data;
//        private Node nextNode;
//
//        public Node(T data) {
//            this.data = data;
//        }
//        public Node(T data, Node nextNode) {
//            this.data = data;
//            this.nextNode = nextNode;
//        }
//    }
    
    public ArraySet(){
        this(DEFAULT_INITIAL_CAPACITY);
    }
    
    public ArraySet(int initialCapacity) {
        numberOfElements = 0;
        setArray = (T[]) new Object[initialCapacity];
    }
    
    ///
    
    public boolean add(T newEntry) {
        for (int i = 0; i < numberOfElements; i++) {
            if (setArray[i].equals(newEntry))
                return false;
        }
        
        if (isArrayFull())
            doubleArray();
        
        setArray[numberOfElements] = newEntry;
        numberOfElements++;
        return true;
    }
    
    private boolean isArrayFull(){
        return numberOfElements == setArray.length;
    }
    
    private void doubleArray(){
        T[] oldSetArray = setArray;
        int oldSize = oldSetArray.length;
        
        setArray = (T[]) new Object[oldSize * 2];
        for (int i = 0; i < numberOfElements; i++) {
            setArray[i] = oldSetArray[i];
        }
    }
    
    public boolean remove(T anEntry){
        for(int i = 0; i < numberOfElements; i++) {
            if (setArray[i].equals(anEntry)) {
                removeGap(i);
                numberOfElements--;
                return true;
        }
    }
        return false;
    }
    
    private void removeGap(int index) {
        for (int i = 0; i < numberOfElements; i++){
            setArray[i] = setArray[i + 1];
        }
    }
    
    public boolean contains(T anEntry) {
        for (int i = 0; i < numberOfElements; i++) {
            if (setArray[i].equals(anEntry))
                return true;
        }
        
        return false;
    }
    
    public T getElement(int index){
        T result = null;
        
        if(index > 0 && index <= numberOfElements){
            result = setArray[index - 1];
        }
        return result;
    }
    
    public int size() {
        return numberOfElements;
    }
    
    public boolean isEmpty() {
        return numberOfElements == 0;
    }
    
}
