
package adt;

public interface LinkedListInterface<T> {
    
boolean add(T newElement);
//Description: Appends newElement to the end of the list.
//Precondition: The newElement is not null.
//Postcondition: The newElement has been appended to the end of the list.
//Return: True if the newElement is successfully appended to the end of the list; False otherwise.

boolean add(T newElement, int index);
//Description: Appends newElement to the specified position (index).
//Precondition: The newElement is not null, the index must be between 1 to the number of total elements +1.
//Postcondition: The newElement has been appended to the specified position (index).
//Return: True if the newElement is successfully appended to the specified position (index); False otherwise.

T getElement(int index);
//Description: Retrieves the element at the specified position (index) from the list.
//Precondition: The index must be between 1 to the number of total elements.
//Postcondition: The list remains unchanged.
//Return: The element at the specified position (index)         

boolean update(T newElement, T updateElement);
//Description: Replaces the updateElement with newElement in the list.
//Precondition: The updateElement must exist in the list, the newElement is not null.
//Postcondition: The updateElement is replaced with the newElement.
//Return: True if the updateElement is successfully replaced with the newElement; False otherwise.

boolean update(T newElement, int index);
//Description: Replaces the element at index with newElement in the list.
//Precondition: The index must be between 1 to the number of total elements, the newElement is not null.
//Postcondition: The element at index has been replaced with newElement.
//Return: True if the element at index is successfully replaced with the newElement; False otherwise.


boolean remove(T removeElement);
//Description: Deletes the first occurrence of the removeElement in the list.
//Precondition:  The removeElement must exist in the list.
//Postcondition: The removeElement has been deleted from the list.
//Return: True if the removeElement is successfully deleted from the list; False otherwise.

boolean remove(int index);
//Description: Deletes the element at the index in the list.
//Precondition: The index must be between 1 to the number of total elements
//Postcondition: The element at the index has been deleted from the list. 
//Return: True if the element at the index is successfully deleted from the list; False otherwise.

boolean clear();
//Description: Deletes all the elements in the list.
//Precondition: The list is not empty.
//Postcondition: All the elements in the list are deleted, number of elements is updated to 0. 
//Return: True if all the elements in the list are successfully deleted from the list; False otherwise.

boolean contains(T element);
//Description: Check if the element exists in the list.
//Postcondition: The list remains unchanged.
//Return: True if the element exists in the list; False otherwise.

boolean isEmpty();
//Description: Checks if the list is empty.
//Postcondition: The list remains unchanged. 
//Return: True if the list is empty (contain no elements); False otherwise.

boolean isFull();
//Description: Checks if the list is full.
//Postcondition: The list remains unchanged. 
//Return: True if the list is full (contain maximum elements); False otherwise.

int size();
//Description: Checks the number of elements in the list.
//Postcondition: The list remains unchanged. 

T head();
//Description: Retrieves the first element from the list.
//Postcondition: The list remains unchanged. 
//Return: The first element in the list.

T tail();
//Description: Retrieves the last element from the list.
//Postcondition: The list remains unchanged. 
//Return: The last element in the list.

int indexOf(T element);
//Description: Retrieves the index of the element in the list.
//Postcondition: The list remains unchanged. 
//Return: The index of the element in the list.

T random();
//Description: Retrieves a random element from the list.
//Postcondition: The list remains unchanged. 
//Return: A random element from the list.

}
