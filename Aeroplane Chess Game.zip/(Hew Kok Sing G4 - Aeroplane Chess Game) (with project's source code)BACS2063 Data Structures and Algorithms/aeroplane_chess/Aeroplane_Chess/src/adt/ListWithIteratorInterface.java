package adt;

import java.util.Iterator;

public interface ListWithIteratorInterface<T> {
    
    public Iterator<T> getIterator();
  
    public boolean add(T newObj);
    //Description: Add new object to the end of the list.
    //Precondition: The newObj is not null and the list is not full.
    //Postcondition: The newObj added to the end of the list.
    //Return: Return true iff the newObj succesfully added.
    public boolean add(int position, T newObj);
    //Description: Add new object to list at the given position.
    //Precondition: The newObj is not null the position given must not exceed the size and is a valid position.
    //Postcondition: The newObj added to the given position list.
    //Return: Return true iff the newObj succesfully added at given position.
    public boolean contains(T obj);
    //Description: Check if the object is in the list.
    //Return: Return true iff object is in the list.
    public T getObj(int position);
    //Description: Get object from the list at the given position.
    //Precondition: The position given must be correct, list element should not be null at the position.
    //Postcondition: The object is obtained from the given position in the list.
    //Return: return the object at given position in the list
    public int checkPosition(T obj); //*
    //Description: Get the position of the object.
    //Precondition: The obj must not be null and must be contains in the list.
    //Postcondition: The object position is obtained.
    //Return: Return the object position, return 0 if the obj is not in the list.
    public T remove(int position);
    //Description: Remove object from the list at the given position.
    //Precondition: The position given must be correct, list element should not be null at the position.
    //Postcondition: The object is removed from the list from the given position.
    //Return: Return the removed object.
    public T remove(T obj); //*
    //Description: Remove object from the list.
    //Precondition: The obj must not be null and must be contains in the list.
    //Postcondition: The object is removed from the list.
    //Return: Return the removed object.
    public boolean replace(int position, T newObj);
    //Description: Replace object data in the list at the given position.
    //Precondition: The position given must be correct, list element should not be null at the position.
    //Postcondition: The object data is replaced in the list at the given position.
    //Return: Return true iff the object data is replaced at the given position.
    public boolean replace(T obj, T newObj); //*
    //Description: Replace object data in the list with newObj.
    //Precondition: The position given must be correct, list element should not be null at the position.
    //Postcondition: The object data is replaced in the list with newObj.
    //Return: Return true iff the object data is replaced with newObj.
    public void clear();
    //Description: Clear all object in the list.
    //Precondition: The list should not be null.
    //Postcondition: All object is removed from the list.
    public boolean isFull();
    //Description: Check if the list is full.
    //Return: Return true iff the list is full.
    public int size();
    //Description: Obtain the number of item in the list.
    //Precondition: The list must not be null..
    //Return: Return the number of object in the list.
    public boolean isEmpty();
    //Description: Check if the list is empty.
    //Return: Return true iff the list is empty.
    public void subList(int fromPosition, int toPosition); //*
    //Description: View list object from fromPosition to toPosition.
    //Precondition: Object must be inside the list from fromPosition to toPosition position. The range of fromPosition to toPosition must be within the size of list.
    //Postcondition: Object from position fromPosition to toPosition are printed.
    public boolean removeRange(int fromPosition, int toPosition); //*
    //Description: Remove all object from fromIndex to toIndex.
    //Precondition: Object must be inside the list from fromIndex to toIndex position.The range of fromIndex to toIndex must be within the size of list.
    //Postcondition: Object from fromIndex to toIndex are removed.
    //Return: Return true iff all element from fromPosition to toPosition succesfully deleted
    public boolean addAll(ListWithIteratorInterface<T> list); //*
    //Description: Add all object from a list to another list.
    //Precondition: The object added in with the original existed object must not exceed the capacity of array. 
    //Postcondition: The list contained all object from another list.
    //Return: Return true iff successfully added all 
}
