package adt;

public interface SetInterface<T> {
    
    public boolean add(T newEntry);
    /*
    Description: Add an new unique entry to the set of array. 
    Precondition: newEntry must not exist in the array.
    Postcondition: The newEntry add to the array.
    Return: Return true iff the newEntry succesfully added.
    */
    public boolean remove(T anEntry);
    /*
    Description: Remove the existing entry in the array.
    Precondition: The anEntry must exist in the array.
    Postcondition: The anEntry removed from the array.
    Return: Return true iff the anEntry succesfully removed.
    */
    public boolean contains(T anEntry);
    /*
    Description: Check the anEntry is exist in the array.
    Return: Return true iff the anEntry existed in the array.
    */
    public T getElement(int index);
    /*
    Description: Get the entry from specific index in the array.
    Precondition: The index must be in the range.
    Postcondition: The anEntry get in the array.
    Return: Return anEntry data in the array.
    */
    public int size();
    /*
    Description: Check the size of the array.
    Return: Return the size value of the array.
    */
    public boolean isEmpty();
    /*
    Description: Check the array is empty.
    Return: Return true iff the array is empty.
    */
}
