package adt;

public class SortedArrayList<T extends Comparable<T>> implements SortedListInterface<T> {

  private T[] array;
  private int size;
  private static final int DEFAULT_CAPACITY = 3;

  public SortedArrayList() {
    this(DEFAULT_CAPACITY);
  }

  public SortedArrayList(int initialCapacity) {
    size = 0;
    array = (T[]) new Comparable[initialCapacity];
  }

  public boolean add(T newObject) {
         
      if(isFull()){
          return false;
      }
      else
      {
          int i = 0;
          while (i<size &&newObject.compareTo(array[i])>0){
              i++;
          }
          int newIndex = i ;
          int lastIndex = size-1;
          for(int index= lastIndex; index >= newIndex; index--){
                array[index +1]= array[index];
          }
      
          array[i] = newObject;
          size++;
          
          return true;
      }          
  }

    
  @Override
  public boolean remove(T object) {
        //check if array empty
        if(isEmpty())
            return false;
        else{
            int i =0;
            while(i<size && array[i].compareTo(object)<0){
                i++;
            }
            if(array[i].equals(object)){
                
                int removedIndex = i;
                int lastIndex = size - 1;

                for (int index = removedIndex; index < lastIndex; index++) {
                  array[index] = array[index + 1];
                }
                size--;
                return true;
            }
            return false;
        }      
        
  }

  public void clear() {
    size = 0;
  }

  public boolean contains(T object) {
    boolean found = false;
    for (int index = 0; !found && (index < size); index++) {
      if (object.equals(array[index])) {
        found = true;
      }
    }
    return found;
  }

  public int getLength() {
    return size;
  }

  public boolean isEmpty() {
    return size == 0;
  }
  
  public boolean isFull(){
      return size == DEFAULT_CAPACITY;
  }
  
  public T getObject(int position){ //
        T result = null;
        
        if(position >= 0 && position < size){
            result = array[position];
        }
        return result;
  }
  
  public int checkPosition(T object){ //
        int position = 0;
        
        for(int index = 0; index < size; index++){
            if(object == array[index]){
                position = index + 1;
            }
        }
        return position;
  }
  
  public String toString() {
    String outputStr = "";
    for (int index = 0; index < size; ++index) {
      outputStr += array[index] + "\n";
    }

    return outputStr;
  }
  
}
