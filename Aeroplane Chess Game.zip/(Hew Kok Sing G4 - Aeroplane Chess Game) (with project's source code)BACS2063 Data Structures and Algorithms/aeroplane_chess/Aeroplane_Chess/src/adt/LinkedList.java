package adt;

import java.util.Random;

public class LinkedList<T> implements LinkedListInterface<T>{
    private Node firstNode;
    private int numberOfElement; //0 by default
    
    //inner class - Node class (private class as it only access by linkedlist class)
    private class Node{
        private T data;
        private Node nextNode;

        public Node(T data) {
            this.data = data;
        }
        public Node(T data, Node nextNode) {
            this.data = data;
            this.nextNode = nextNode;
        }
    }

    public LinkedList() {}
    
    public LinkedList(Node fisrtNode) {
        this.firstNode = fisrtNode;
        numberOfElement++;
    }

    @Override
    public boolean add(T newElement) {
        if(newElement == null) //do not add null element
            return false;
        
        Node newNode = new Node(newElement); //Node that add to the end of the list
        
        if(isEmpty()) //if empty just add
            firstNode = newNode;
        else //add to lastNode.next
        {
            Node currentNode = firstNode;
            while(currentNode.nextNode != null)
            {
                currentNode = currentNode.nextNode;
            }
            
            currentNode.nextNode = newNode;
        }
        
        numberOfElement++;
        return true;
    }

    @Override
    public boolean add(T newElement, int index) {
        if(newElement == null || (index < 1 && index > numberOfElement+1))
            return false;
        
        Node newNode = new Node(newElement);
        Node currentNode = firstNode;
        
        if(isEmpty())
            firstNode = newNode;
        else if(index == 1) //index start at 1, the newElement add to the first position
        {
            firstNode = newNode;
            firstNode.nextNode = currentNode;
        } 
        else //add to the middle of the list
        {
            Node afterNode = currentNode.nextNode;
            
            for(int cp = 1;cp < index-1;cp++)
            {
                currentNode = currentNode.nextNode;
                afterNode = afterNode.nextNode;
            }
            
            currentNode.nextNode = newNode;
            newNode.nextNode = afterNode;
            
        }
        numberOfElement++;
        return true;
    }

    @Override 
    public T getElement(int index) { 
        if(index < 1 || index > numberOfElement)
            return null;
        
        Node currentNode = firstNode;
        
        for(int cp=1;cp<index;cp++)
        {
            currentNode = currentNode.nextNode;
        }
        
        return currentNode.data;
    }

    @Override 
    public boolean update(T newElement, T updateElement) {
        if(newElement == null || !contains(updateElement))
            return false;
        
        Node currentNode = firstNode;
        
        while(currentNode.data != updateElement)
        {
            currentNode = currentNode.nextNode;
        }
        
        currentNode.data = newElement;
        return true;
        
    }

    @Override
    public boolean update(T newElement, int index) {
        if(newElement == null || (index < 1 || index > numberOfElement))
            return false;
        
        Node currentNode = firstNode;
        
        for(int cp=1;cp<index;cp++)
        {
            currentNode = currentNode.nextNode;
        }
        
        currentNode.data = newElement;
        
        return true;
    }

    @Override //check...............
    public boolean remove(T removeElement) { //cannot remove 1st element
        if(isEmpty() || removeElement == null)
            return false;
        
            Node currentNode = firstNode;
            Node beforeNode = null;
            
            if(indexOf(removeElement) == 1)
            {
                firstNode = currentNode.nextNode;
            }
            else
            {
                while(currentNode.data != removeElement)
                {
                    beforeNode = currentNode;
                    currentNode = currentNode.nextNode; 
                }           
                
                beforeNode.nextNode = currentNode.nextNode;
            }  
        numberOfElement--;
        return true;
    }

    @Override
    public boolean remove(int index) {
        if(isEmpty() || (index < 1 || index > numberOfElement))
            return false;

            Node currentNode = firstNode;
            
            if(index == 1)
            {
                firstNode = currentNode.nextNode;
            }else
            {
                Node beforeNode = null;

                for(int cp=1;cp<index;cp++)
                {
                    beforeNode = currentNode;
                    currentNode = currentNode.nextNode;      
                }

                beforeNode.nextNode = currentNode.nextNode;
                
            }
        
        numberOfElement--;
        return true;
    }

    @Override
    public boolean clear() {
        if(isEmpty())
            return false; // cannot clear since it is already empty
        
        firstNode = null;
        numberOfElement = 0;
        return true;
    }

    @Override
    public boolean contains(T element) {
        boolean contains = false;
        if(isEmpty() || element == null)
            return contains;
        
        Node currentNode = firstNode;
        
        while(!contains && currentNode != null)
        {
            if(currentNode.data.equals(element))
                contains = true;
            else
                currentNode = currentNode.nextNode;
        }
        
        return contains;
    }

    @Override
    public boolean isEmpty() {
        return firstNode == null || numberOfElement == 0;
    }

    @Override
    public boolean isFull() {
        return false; // impossible to be full for linked list
    }

    @Override
    public int size() {
        return numberOfElement;
    }

    @Override
    public T head() {
        if(isEmpty())
            return null;
        
        return firstNode.data;
    }

    @Override
    public T tail() {
        if(isEmpty())
            return null;
        
        Node currentNode = firstNode;
        
        while(currentNode.nextNode != null)
        {
            currentNode = currentNode.nextNode;
        }
        
        return currentNode.data;
    }
    
    @Override //check...............
    public int indexOf(T element) {
        int index = 1;

        Node currentNode = firstNode;

        while (currentNode.data != element) {
            currentNode = currentNode.nextNode;
            index++;
        }
        return index;
    }
    
    @Override
        public T random() 
        {
            Random random = new Random();
            int n = random.nextInt(numberOfElement);
            Node currentNode = firstNode;
            while(--n>=0) {
                currentNode = currentNode.nextNode;
            }
            return currentNode.data;
        }  

    @Override
    public String toString() {
            String str = "";
            Node currentNode = firstNode;
            int i=1;
            while(currentNode != null) //dont check currentNode.nextNode as it will not append the data of the last node
            {
                str+=i+". Player "+ i +currentNode.data + "\n";
                currentNode = currentNode.nextNode;
                i++;
            }  
            return str;
        }

        
    }
    
    
    
   
