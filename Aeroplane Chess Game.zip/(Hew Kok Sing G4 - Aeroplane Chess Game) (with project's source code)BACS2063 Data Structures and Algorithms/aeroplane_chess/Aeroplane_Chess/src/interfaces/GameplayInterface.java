package interfaces;

import entity.Dice;

public interface GameplayInterface {
    
    public int getCoin();//
    
    public boolean isRevert();//
    
    public void setRevert(boolean revert);//
    
    //operation
    public int addCoin(int coin); //
    
    public int subtractCoin(int coin); //
    
    public int advancePlayerPosition(int positionIncrease); //
    
    public int decreasePlayerPosition(int positionDecrease); //
    
    public int resetPlayerPosition(int resetPosition); //
    
    public Dice rollDice(); //
}
